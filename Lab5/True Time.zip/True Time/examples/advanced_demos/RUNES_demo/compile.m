disp('RUNES_demo/robot/left_init.cpp');
ttmex -g robot/left_init.cpp
disp('RUNES_demo/robot/right_init.cpp');
ttmex -g robot/right_init.cpp
disp('RUNES_demo/robot/tmote_init.cpp');
ttmex -g robot/tmote_init.cpp
disp('RUNES_demo/robot/mega128_init.cpp');
ttmex -g robot/mega128_init.cpp
disp('RUNES_demo/robot/megaultra_init.cpp');
ttmex -g robot/megaultra_init.cpp
disp('RUNES_demo/node/node_init.cpp');
ttmex -g node/node_init.cpp
